/*
 * Jorge González
 * 8-1002-2167
 */

public class Main {
    public static void main(String[] args) {
        Estado obj = new Estado();
        // variables de trabajo
        int i;
        char num[], noma[];

        // Imprimir vector num[]
        num = obj.getNum();
        System.out.println("Vector num[]");
        for (i = 0; i < num.length; i++) {
            System.out.print(" " + num[i]);
        }
        System.out.println("\n------------------------");
        // Imprimir vector noma[]
        noma = obj.getNoma();
        System.out.println("Vector noma[]");
        for (i = 0; i < noma.length; i++) {
            System.out.print(" " + noma[i]);
        }
        System.out.println("\n______________________");
        // Imprimir estado
        if (obj.verificarEstado()) {
            System.out.println("Son Iguales!");
        } else {
            System.out.println("Son Diferentes!");
        }
    }
}
