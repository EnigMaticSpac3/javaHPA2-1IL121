/*
 * Jorge González
 * 8-1002-2167
 */

public class Estado {
    private char num[];
    private char noma[];

    public Estado () {
        num   = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
        noma  = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'p', 'j'};
        // for (int i = 0; i < num.length; i++) {
        //     num[i]  = i*i+1;
        //     noma[i] = i+1;
        // }
    }

    public void asignar(char[] num, char[] noma) {
        this.num = num;
        this.noma = noma;
    }

    public boolean verificarEstado() {
        boolean resp = true;
        for (int i = 0; i < num.length; i++) {
            if (num[i] != noma[i]) {
                resp = false;
            }
        }
        return resp;
    }

    public char[] getNum() { return num; }
    public char[] getNoma() { return noma; }
}
