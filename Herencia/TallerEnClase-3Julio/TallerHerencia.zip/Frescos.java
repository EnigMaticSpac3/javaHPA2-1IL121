public class Frescos extends Producto {
    
    public double calcularCostoProd(int cantProd) {
        return cantProd * 100;
    }
}
