/*
 * Integrantes:
    
    @Jefferson Chacon   | 20-70-7314
    @Jorge Gonzalez     | 8-1002-2167
    @Amy Him            | 3-753-2253 
    @DIego Ramos        | 8-1002-1456
 */
// APLICACIÓN DE CONSTRUCTORES 
public class Main {
    public static void main(String[] args) {
        Operaciones obj  = new Operaciones();
        Operaciones obj1 = new Operaciones(3,5,8.00);
        // Operaciones obj2 = new Operaciones(3);
        obj.asignar(0, 0, 0);
        obj1.asignar(0, 0, 0);
    }
}
