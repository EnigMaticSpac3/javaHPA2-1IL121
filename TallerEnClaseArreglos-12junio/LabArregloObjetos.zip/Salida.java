class Salida {
    private String nombre;
    private double notaf;


    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public double getNotaf() {
        return notaf;
    }
    public void setNotaf(double notaf) {
        this.notaf = notaf;
    }

    
}
